import { Component, OnInit } from '@angular/core';
import { FirestoreService } from '../services/firestore.service';

@Component({
  selector: 'app-image-list',
  templateUrl: 'image-list.page.html',
  styleUrls: ['image-list.page.scss'],
})
export class ImageListPage implements OnInit {
  images = [];

  constructor(private firestoreService: FirestoreService) {}

  ngOnInit() {
    this.firestoreService.getData().subscribe((data) => {
      this.images = data;
    });
  }
}
