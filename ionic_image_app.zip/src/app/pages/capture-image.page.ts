import { Component } from '@angular/core';
import { Camera, CameraResultType } from '@capacitor/camera';
import { FirestoreService } from '../services/firestore.service';
import { SupabaseService } from '../services/supabase.service';

@Component({
  selector: 'app-capture-image',
  templateUrl: 'capture-image.page.html',
  styleUrls: ['capture-image.page.scss'],
})
export class CaptureImagePage {
  image: string = '';
  description: string = '';
  dateCreated: string = new Date().toISOString();

  constructor(
    private firestoreService: FirestoreService,
    private supabaseService: SupabaseService
  ) {}

  async captureImage() {
    const photo = await Camera.getPhoto({
      resultType: CameraResultType.Uri,
      source: CameraSource.Camera,
      quality: 100,
    });

    this.image = photo.webPath!;
  }

  async saveData() {
    const imageUrl = await this.supabaseService.uploadImage(this.image);
    this.firestoreService.saveData(this.description, imageUrl, this.dateCreated);
  }
}
