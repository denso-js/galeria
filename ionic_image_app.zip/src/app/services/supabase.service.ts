import { Injectable } from '@angular/core';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient('https://your-project.supabase.co', 'your-anon-key');

@Injectable({
  providedIn: 'root'
})
export class SupabaseService {
  async uploadImage(image: string) {
    const file = await fetch(image);
    const blob = await file.blob();
    const { data, error } = await supabase.storage.from('images').upload('image.jpg', blob);

    if (error) throw error;

    return data?.Key;
  }
}
