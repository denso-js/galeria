import { Injectable } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { doc, setDoc } from 'firebase/firestore';

@Injectable({
  providedIn: 'root'
})
export class FirestoreService {
  constructor(private firestore: AngularFirestore) {}

  saveData(description: string, imageUrl: string, dateCreated: string) {
    const data = { description, imageUrl, dateCreated };
    const docId = this.firestore.createId();
    return setDoc(doc(this.firestore.firestore, 'images', docId), data);
  }

  getData() {
    return this.firestore.collection('images').valueChanges();
  }
}
