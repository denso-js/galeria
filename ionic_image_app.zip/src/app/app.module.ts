import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicModule } from '@ionic/angular';
import { AppComponent } from './app.component';
import { Camera } from '@capacitor/camera';
import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { FirebaseConfig } from './firebase.config';
import { FirestoreService } from './services/firestore.service';
import { SupabaseService } from './services/supabase.service';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AngularFireModule.initializeApp(FirebaseConfig),
    AngularFirestoreModule
  ],
  providers: [FirestoreService, SupabaseService],
  bootstrap: [AppComponent]
})
export class AppModule { }
